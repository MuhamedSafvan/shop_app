import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'dart:convert';

import 'package:carousel_slider/carousel_slider.dart';

class HomeSlider extends StatelessWidget {
  Future<void> readJson() async {
    Uri uri = Uri.parse("http://omanphone.smsoman.com/api/configuration");
    var response = await get(uri);
    final data = await json.decode(response.body);
    return data;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height / 4,
      color: Colors.black12,
      child: FutureBuilder(
          future: readJson(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              Map<String, dynamic> map = snapshot.data as Map<String, dynamic>;
              List list = map['data']['slider'];
              return CarouselSlider.builder(
                itemCount: list.length,
                itemBuilder: (context, index, hero) {
                  return Image.network(list[index]['image']);
                },
                options: CarouselOptions(
                  aspectRatio: 16 / 9,
                  height: 200, scrollDirection: Axis.horizontal,
                  
                  // enlargeStrategy: CenterPageEnlargeStrategy.height,
                  // height: MediaQuery.of(context).size.height,
                  // enlargeCenterPage: true,
                  autoPlay: true,
                ),
              );
            } else {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
          }),
    );
  }
}
