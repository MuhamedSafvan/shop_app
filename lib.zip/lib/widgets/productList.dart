import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'dart:convert';

import 'package:shop_app/pages/productPage.dart';

class ProductList extends StatefulWidget {
  @override
  _ProductListState createState() => _ProductListState();
}

class _ProductListState extends State<ProductList> {
  Future<void> readJson() async {
    Uri uri = Uri.parse("http://omanphone.smsoman.com/api/homepage");
    var response = await get(uri);
    final data = await json.decode(response.body);
    return data;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black12,
      padding: EdgeInsets.all(10),
      height: 480,
      // height: MediaQuery.of(context).size.height -
      //     (MediaQuery.of(context).size.height / 5),
      child: FutureBuilder(
          future: readJson(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              List list = [snapshot.data];
              List newList = list[0][0]["data"]["items"];
              return InkWell(
                onTap: () {
                  Navigator.of(context).push(
                    new MaterialPageRoute(
                      builder: (context) => ProductPage(),
                    ),
                  );
                },
                child: GridView.builder(
                    // padding: EdgeInsets.all(value),
                    controller: ScrollController(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      crossAxisCount: 2,
                    ),
                    itemCount: newList.length,
                    itemBuilder: (context, index) {
                      // return Text("DOn't");
                      return Container(
                          color: Colors.yellow,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              // Image.network(newList[index]['image']),
                              Column(
                                children: [
                                  Text(newList[index]['name'],
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.normal,
                                          color: Colors.grey[600])),
                                  Text(
                                    'OMR ${newList[index]['price']}',
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red[800]),
                                  ),
                                ],
                              )
                            ],
                          ));
                      // return Image(image: (newList[index]['image']));
                    }),
              );
            } else {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
          }),
    );
  }
}
